# KPI Definitions

| KPI | Description |
|-----|-------------|
| Total Revenue | Total ticket sales |
| Route Utilization | Seats sold per route |
| Booking Rate | Tickets per hour |
| Cancellation Rate | % of canceled tickets |
