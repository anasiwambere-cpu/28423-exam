# Dashboard Mockups

## Executive Summary
- Total Revenue
- Total Tickets Sold
- Active Routes

## Audit Dashboard
- Blocked operations
- Trigger violations

## Performance Dashboard
- Top routes
- Peak hours
