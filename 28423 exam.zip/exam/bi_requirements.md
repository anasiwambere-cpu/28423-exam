# BI Requirements

## Stakeholders
- Transport Managers
- Finance Department
- Operations Supervisors

## Decision Support Needs
- Revenue tracking
- Route performance
- Seat occupancy
- Agent performance

## Reporting Frequency
- Daily
- Weekly
- Monthly
